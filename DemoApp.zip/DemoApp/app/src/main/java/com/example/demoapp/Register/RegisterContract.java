package com.example.demoapp.Register;

import com.google.android.material.textfield.TextInputLayout;

public interface RegisterContract {
    interface Presenter{
        boolean validateFirstname();
        boolean validateLastname();
        boolean validateEmail();
        boolean validateAddress();
        boolean validateCity();
        boolean validateTelephone();
        boolean validatePassword();
        boolean validateConfirmPassword();

        void confirmValidation();
    }

    interface View{
        String getUserFirstname();
        String getUserLastname();
        String getUserEmail();
        String getUserAddress();
        String getUserCity();
        String getUserTelephone();
        String getUserPassword();
        String getConfirmPassword();

        void SetErrorMessage(int inputLayout, String message);
    }

}
