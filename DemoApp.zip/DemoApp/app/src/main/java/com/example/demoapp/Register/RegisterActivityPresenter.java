package com.example.demoapp.Register;

import android.util.Patterns;
import android.widget.Toast;

public class RegisterActivityPresenter implements RegisterContract.Presenter {

    RegisterContract.View view;

    public RegisterActivityPresenter(RegisterContract.View view) {
        this.view = view;
    }


    @Override
    public boolean validateFirstname() {
        if (view.getUserFirstname().isEmpty()){
            view.SetErrorMessage(1, "Enter Your Firstname");
            return false;
        }
        else{
            view.SetErrorMessage(1, null);
            return true;
        }
    }

    @Override
    public boolean validateLastname() {
        if (view.getUserLastname().isEmpty()){
            view.SetErrorMessage(2, "Enter Your Lastname");
            return false;
        }
        else{
            view.SetErrorMessage(2, null);
            return true;
        }
    }

    @Override
    public boolean validateEmail() {
        if (view.getUserEmail().isEmpty()){
            view.SetErrorMessage(3, "Enter Your Email");
            return false;
        }
        else if (!Patterns.EMAIL_ADDRESS.matcher(view.getUserEmail()).matches()){
            view.SetErrorMessage( 3,"Enter correct Email address");
            return false;
        }
        else{
            view.SetErrorMessage(3, null);
            return true;
        }
    }

    @Override
    public boolean validateAddress() {
        if (view.getUserAddress().isEmpty()){
            view.SetErrorMessage(4, "Enter Your Address");
            return false;
        }
        else{
            view.SetErrorMessage(4, null);
            return true;
        }
    }

    @Override
    public boolean validateCity() {
        if (view.getUserCity().isEmpty()){
            view.SetErrorMessage(5, "Enter Your City");
            return false;
        }
        else{
            view.SetErrorMessage(5, null);
            return true;
        }
    }

    @Override
    public boolean validateTelephone() {
        if (view.getUserTelephone().isEmpty()){
            view.SetErrorMessage(6, "Enter Your Lastname.");
            return false;
        }
        else if (view.getUserTelephone().length() > 10){
            view.SetErrorMessage(6, "Telephone number too long.");
            return false;
        }
        else{
            view.SetErrorMessage(6, null);
            return true;
        }
    }

    @Override
    public boolean validatePassword() {
        if (view.getUserPassword().isEmpty()){
            view.SetErrorMessage(7, "Enter Your Password.");
            return false;
        }
        else if (view.getUserPassword().equals(view.getConfirmPassword())){
            view.SetErrorMessage(7, "Password and Confirm aren't equal.");
            return false;
        }
        else{
            view.SetErrorMessage(7, null);
            return true;
        }

    }

    @Override
    public boolean validateConfirmPassword() {
        if (view.getUserPassword().isEmpty()){
            view.SetErrorMessage(8, "Enter Confirm Password.");
            return false;
        }
        else if (view.getUserPassword().equals(view.getConfirmPassword())){
            view.SetErrorMessage(8, "Password and Confirm aren't equal.");
            return false;
        }
        else{
            view.SetErrorMessage(8, null);
            return true;
        }
    }

    @Override
    public void confirmValidation() {
        if (!validateFirstname() | !validateLastname() | !validateEmail() | !validateAddress() | !validateCity() |
        !validateTelephone() | !validatePassword() | !validateConfirmPassword()){
            return;
        }
//        Toast.makeText(getContext(), "Saveds", Toast.LENGTH_SHORT).show();
    }


}
