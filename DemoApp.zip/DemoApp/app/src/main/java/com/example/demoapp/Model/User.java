package com.example.demoapp.Model;

public class User {
    private String firstname;
    private String lastname;
    private String email;
    private String address;
    private String city;
    private String telephone;
    private String password;

    public User(String firstname, String lastname, String email, String address, String city, String telephone, String password) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.address = address;
        this.city = city;
        this.telephone = telephone;
        this.password = password;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getCity() {
        return city;
    }

    public String getTelephone() {
        return telephone;
    }

    public String getPassword() {
        return password;
    }
}
