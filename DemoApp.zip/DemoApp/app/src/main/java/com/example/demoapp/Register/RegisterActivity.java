package com.example.demoapp.Register;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.demoapp.R;
import com.google.android.material.textfield.TextInputLayout;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class RegisterActivity extends AppCompatActivity implements RegisterContract.View {

    @BindView(R.id.textInputFirstname)
    TextInputLayout textInputFirstname;
    @BindView(R.id.textInputLastname)
    TextInputLayout textInputLastname;
    @BindView(R.id.textInputEmail)
    TextInputLayout textInputEmail;
    @BindView(R.id.textInputAddress)
    TextInputLayout textInputAddress;
    @BindView(R.id.textInputCity)
    TextInputLayout textInputCity;
    @BindView(R.id.textInputTelephone)
    TextInputLayout textInputTelephone;
    @BindView(R.id.textInputPassword)
    TextInputLayout textInputPassword;
    @BindView(R.id.textInputConfirmPassword)
    TextInputLayout textInputConfirmPassword;

    @BindView(R.id.registerButton)
    Button registerButton;

    @BindView(R.id.goToLogin)
    TextView goToLogin;

    RegisterContract.Presenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        ButterKnife.bind(this);

        presenter = new RegisterActivityPresenter(this);
    }


    @Override
    public String getUserFirstname() {
        return textInputFirstname.getEditText().getText().toString().trim();
    }

    @Override
    public String getUserLastname() {
        return textInputLastname.getEditText().getText().toString().trim();
    }

    @Override
    public String getUserEmail() {
        return textInputEmail.getEditText().getText().toString().trim();
    }

    @Override
    public String getUserAddress() {
        return textInputAddress.getEditText().getText().toString().trim();
    }

    @Override
    public String getUserCity() {
        return textInputCity.getEditText().getText().toString().trim();
    }

    @Override
    public String getUserTelephone() {
        return textInputTelephone.getEditText().getText().toString().trim();
    }

    @Override
    public String getUserPassword() {
        return textInputPassword.getEditText().getText().toString().trim();
    }

    @Override
    public String getConfirmPassword() {
        return textInputConfirmPassword.getEditText().getText().toString().trim();
    }

    @Override
    public void SetErrorMessage(int inputLayout, String message) {
        switch (inputLayout){
            case 1:
                textInputFirstname.setError(message);
            case 2:
                textInputLastname.setError(message);
            case 3:
                textInputEmail.setError(message);
            case 4:
                textInputAddress.setError(message);
            case 5:
                textInputCity.setError(message);
            case 6:
                textInputTelephone.setError(message);
            case 7:
                textInputPassword.setError(message);
            case 8:
                textInputConfirmPassword.setError(message);
            default:
        }
    }

    @OnClick(R.id.registerButton)
    public void setRegisterButton(){
        presenter.confirmValidation();
    }


}
